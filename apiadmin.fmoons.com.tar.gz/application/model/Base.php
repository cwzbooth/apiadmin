<?php
/**
 *
 * @since   2019-04-23
 * @author  zhaoxiang <zhaoxiang051405@gmail.com>
 */

namespace app\model;

use think\Model;

class Base extends Model {

}
