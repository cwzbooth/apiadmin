<?php
/**
 * 接口字段规则模型
 * @since   2017/07/25 创建
 * @author  zhaoxiang <zhaoxiang051405@gmail.com>
 */

namespace app\model;

class AdminFields extends Base {

}
