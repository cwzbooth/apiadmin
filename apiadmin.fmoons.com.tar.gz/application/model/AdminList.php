<?php
/**
 * @since   2017-07-30
 * @author  zhaoxiang <zhaoxiang051405@gmail.com>
 */

namespace app\model;

class AdminList extends Base {

}
