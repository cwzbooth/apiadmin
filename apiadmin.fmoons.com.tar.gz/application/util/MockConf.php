<?php
/**
 * mock配置和ApiAdmin内置的接口返回数据配置相互转化的类
 * @since   2018-08-23
 * @author  zhaoxiang <zhaoxiang051405@gmail.com>
 */

namespace app\util;

class MockConf {

    public function mockToApiAdmin() {

    }

    public function apiAdminToMock() {

    }
}
